"use strict";
(() => {
  // src/content.ts
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "SCRAPE_PAGE") {
      const pageText = getCleanBodyText();
      const title = document.title;
      const url = window.location.href;
      sendResponse({ text: pageText, title, url });
    }
    if (message.action === "HIGHLIGHT_TEXT") {
      const selection = window.getSelection();
      if (selection) {
        sendResponse({ text: selection.toString() });
      } else {
        sendResponse({ text: "" });
      }
    }
    if (message.action === "MANUAL_SCAN_PAGE") {
      const deadlines = performDeadlineScan();
      const entities = performEntityScan();
      sendResponse({ deadlines, entities });
    }
  });
  function autoScanPage() {
    setTimeout(() => {
      scanPageForDeadlines();
      scanPageForEntities();
    }, 1500);
  }
  window.addEventListener("load", autoScanPage);
  document.addEventListener("DOMContentLoaded", autoScanPage);
  function getCleanBodyText() {
    if (!document.body) return "";
    const bodyClone = document.body.cloneNode(true);
    const elementsToRemove = bodyClone.querySelectorAll("script, style, nav, footer, header, iframe");
    elementsToRemove.forEach((el) => el.remove());
    let text = bodyClone.innerText || bodyClone.textContent || "";
    text = text.replace(/\s+/g, " ").trim();
    return text.substring(0, 5e4);
  }
  function performDeadlineScan() {
    if (!document.body) return [];
    const url = window.location.href;
    const pageText = document.body.innerText || "";
    const detectedDeadlines = [];
    if (url.includes("canvas") || url.includes("instructure.com")) {
      const assignmentRows = document.querySelectorAll(
        ".student-assignment-row, .assignment, .ig-row, .assignment-list-item, li.assignment"
      );
      assignmentRows.forEach((row) => {
        const titleEl = row.querySelector(".title, .assignment_title, .ig-title, a.ig-title, .assignment-title");
        const dueEl = row.querySelector(".due_date, .display_due_date, .due, .due-date, span.due-date");
        if (titleEl && dueEl && titleEl.textContent && dueEl.textContent) {
          detectedDeadlines.push({
            title: `[Canvas] ${titleEl.textContent.trim()}`,
            date: dueEl.textContent.trim(),
            sourceUrl: url
          });
        }
      });
    }
    if (url.includes("github.com")) {
      const milestoneItems = document.querySelectorAll(".milestone-card, .milestone, .milestone-card-header, li.milestone");
      milestoneItems.forEach((item) => {
        const titleEl = item.querySelector(".milestone-title-link, .milestone-title a, h2.milestone-title a, a");
        const dueEl = item.querySelector(".milestone-meta-item, .milestone-meta, .due-date, span.due-date, span");
        if (titleEl && dueEl && titleEl.textContent && dueEl.textContent && dueEl.textContent.includes("Due")) {
          detectedDeadlines.push({
            title: `[GitHub Milestone] ${titleEl.textContent.trim()}`,
            date: dueEl.textContent.trim().replace("Due by", "").trim(),
            sourceUrl: url
          });
        }
      });
    }
    const regexPatterns = [
      /(?:due\s+by|due|deadline)\s*[:\-]?\s*([A-Za-z]+\s+\d{1,2}(?:\s*,\s*\d{4})?|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2})/gi
    ];
    regexPatterns.forEach((pattern) => {
      let match;
      const textSnippet = pageText.substring(0, 1e4);
      while ((match = pattern.exec(textSnippet)) !== null) {
        const extractedDate = match[1];
        const index = match.index;
        const contextText = textSnippet.substring(Math.max(0, index - 50), index).trim();
        let cleanContext = contextText.replace(/\r?\n|\r/g, " ").replace(/\s+/g, " ").trim();
        cleanContext = cleanContext.replace(/^[^a-zA-Z0-9]+/, "");
        if (cleanContext.length > 50) {
          cleanContext = "..." + cleanContext.substring(cleanContext.length - 47);
        }
        if (cleanContext.length < 3) {
          cleanContext = document.title || "Page Deadline";
        }
        detectedDeadlines.push({
          title: `Deadline: "${cleanContext}"`,
          date: extractedDate.trim(),
          sourceUrl: url
        });
      }
    });
    return Array.from(new Set(detectedDeadlines.map((d) => JSON.stringify(d)))).map((s) => JSON.parse(s));
  }
  function scanPageForDeadlines() {
    const uniqueDeadlines = performDeadlineScan();
    if (uniqueDeadlines.length > 0) {
      console.log("AKRAMYG Sensor: Detected deadlines:", uniqueDeadlines);
      uniqueDeadlines.forEach((deadline) => {
        chrome.runtime.sendMessage({
          action: "ADD_EVENT",
          event: {
            type: "deadline",
            data: deadline
          }
        });
      });
    }
  }
  function performEntityScan() {
    if (!document.body) return [];
    const url = window.location.href;
    const pageText = document.body.innerText || "";
    const detectedEntities = [];
    const githubRepoRegex = /https:\/\/github\.com\/([A-Za-z0-9_\-\.]+)\/([A-Za-z0-9_\-\.]+)/gi;
    let match;
    while ((match = githubRepoRegex.exec(pageText)) !== null) {
      detectedEntities.push({
        category: "repository",
        value: match[0],
        title: `${match[1]}/${match[2]}`
      });
    }
    const meetingRegex = /(https:\/\/(?:meet\.google\.com|zoom\.us\/j)\/[A-Za-z0-9_\-\?&=]+)/gi;
    while ((match = meetingRegex.exec(pageText)) !== null) {
      detectedEntities.push({
        category: "meeting_link",
        value: match[0],
        title: "Meeting Link"
      });
    }
    return Array.from(new Set(detectedEntities.map((e) => JSON.stringify(e)))).map((s) => JSON.parse(s));
  }
  function scanPageForEntities() {
    const uniqueEntities = performEntityScan();
    uniqueEntities.forEach((entity) => {
      chrome.runtime.sendMessage({
        action: "ADD_EVENT",
        event: {
          type: "entity",
          data: entity
        }
      });
    });
  }
})();
//# sourceMappingURL=content.js.map
