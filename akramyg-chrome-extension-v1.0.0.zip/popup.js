"use strict";
(() => {
  // src/popup.ts
  document.addEventListener("DOMContentLoaded", () => {
    const statusDot = document.getElementById("status-dot");
    const statusText = document.getElementById("status-text");
    const activeTaskTitle = document.getElementById("active-task-title");
    const focusBadge = document.getElementById("focus-badge");
    const summaryArea = document.getElementById("summary-area");
    const btnAttach = document.getElementById("btn-attach");
    const btnCapture = document.getElementById("btn-capture");
    const btnSummarize = document.getElementById("btn-summarize");
    const btnSaveSettings = document.getElementById("btn-save-settings");
    const btnSaveRelaySettings = document.getElementById("btn-save-relay-settings");
    const btnAutoDiscover = document.getElementById("btn-auto-discover");
    const discoverStatus = document.getElementById("discover-status");
    const inputIp = document.getElementById("ip-address");
    const inputPort = document.getElementById("port");
    const inputCloudRelayEnabled = document.getElementById("cloud-relay-enabled");
    const inputRelayUrl = document.getElementById("relay-url");
    const inputRelayPairingKey = document.getElementById("relay-pairing-key");
    const btnScan = document.getElementById("btn-scan");
    const btnSyncDetected = document.getElementById("btn-sync-detected");
    const btnAddManual = document.getElementById("btn-add-manual");
    const detectedItemsContainer = document.getElementById("detected-items-container");
    const detectedList = document.getElementById("detected-list");
    const manualFallbackContainer = document.getElementById("manual-fallback-container");
    const fallbackMessage = document.getElementById("fallback-message");
    const manualTaskTitle = document.getElementById("manual-task-title");
    const manualTaskDate = document.getElementById("manual-task-date");
    const tabBtnCapture = document.getElementById("tab-btn-capture");
    const tabBtnFocus = document.getElementById("tab-btn-focus");
    const tabBtnSync = document.getElementById("tab-btn-sync");
    const tabContentCapture = document.getElementById("tab-content-capture");
    const tabContentFocus = document.getElementById("tab-content-focus");
    const tabContentSync = document.getElementById("tab-content-sync");
    const distractionCountBadge = document.getElementById("distraction-count-badge");
    const distractionLogsFeed = document.getElementById("distraction-logs-feed");
    const blocklistDomains = document.getElementById("blocklist-domains");
    const btnSaveBlocklist = document.getElementById("btn-save-blocklist");
    const syncConsoleLog = document.getElementById("sync-console-log");
    const btnSyncNow = document.getElementById("btn-sync-now");
    const btnClearLogs = document.getElementById("btn-clear-logs");
    let localDetectedDeadlines = [];
    loadStatus();
    loadConfig();
    loadBlocklist();
    loadDistractionStats();
    loadSyncLogs();
    setTimeout(triggerPageScan, 500);
    btnSaveSettings.addEventListener("click", async () => {
      const ip = inputIp.value.trim();
      const port = inputPort.value.trim();
      if (!ip || !port) {
        alert("Please fill in both IP and Port.");
        return;
      }
      statusText.textContent = "Updating...";
      btnSaveSettings.disabled = true;
      const configResult = await chrome.storage.local.get("config");
      const existingConfig = configResult.config || {};
      chrome.runtime.sendMessage(
        {
          action: "UPDATE_CONFIG",
          config: {
            ...existingConfig,
            androidIp: ip,
            androidPort: port,
            syncIntervalMins: 1
          }
        },
        (response) => {
          btnSaveSettings.disabled = false;
          if (chrome.runtime.lastError) {
            statusText.textContent = "Error saving config";
            return;
          }
          if (response && response.success) {
            setTimeout(loadStatus, 1e3);
          } else {
            statusText.textContent = "Error saving config";
          }
        }
      );
    });
    btnAutoDiscover.addEventListener("click", () => {
      btnAutoDiscover.disabled = true;
      discoverStatus.textContent = "Scanning local network...";
      discoverStatus.style.color = "var(--text-muted)";
      chrome.runtime.sendMessage({ action: "DISCOVER_IP" }, (response) => {
        btnAutoDiscover.disabled = false;
        if (chrome.runtime.lastError) {
          discoverStatus.textContent = "Discovery failed.";
          discoverStatus.style.color = "var(--error)";
          return;
        }
        if (response && response.success && response.ip) {
          inputIp.value = response.ip;
          discoverStatus.textContent = `Found server: ${response.ip}`;
          discoverStatus.style.color = "#2E7D32";
          btnSaveSettings.click();
        } else {
          discoverStatus.textContent = "Server not found on local network.";
          discoverStatus.style.color = "var(--error)";
        }
      });
    });
    btnSaveRelaySettings.addEventListener("click", async () => {
      const enabled = inputCloudRelayEnabled.checked;
      const url = inputRelayUrl.value.trim();
      const pairingKey = inputRelayPairingKey.value.trim();
      if (enabled && (!url || !pairingKey)) {
        alert("Please configure both Relay Server URL and Pairing passphrase.");
        return;
      }
      statusText.textContent = "Updating...";
      btnSaveRelaySettings.disabled = true;
      const configResult = await chrome.storage.local.get("config");
      const existingConfig = configResult.config || {};
      chrome.runtime.sendMessage(
        {
          action: "UPDATE_CONFIG",
          config: {
            ...existingConfig,
            cloudRelayEnabled: enabled,
            cloudRelayUrl: url,
            cloudRelayPairingKey: pairingKey
          }
        },
        (response) => {
          btnSaveRelaySettings.disabled = false;
          if (chrome.runtime.lastError) {
            statusText.textContent = "Error saving config";
            return;
          }
          if (response && response.success) {
            statusText.textContent = "Relay config saved";
            setTimeout(loadStatus, 1e3);
          } else {
            statusText.textContent = "Error saving config";
          }
        }
      );
    });
    btnAttach.addEventListener("click", async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length === 0 || !tabs[0].url) {
        alert("No active page detected.");
        return;
      }
      const activeTab = tabs[0];
      btnAttach.disabled = true;
      btnAttach.textContent = "Attaching...";
      chrome.runtime.sendMessage(
        {
          action: "ADD_EVENT",
          event: {
            type: "page_attach",
            data: {
              url: activeTab.url,
              title: activeTab.title || "Untitled Page"
            }
          }
        },
        (response) => {
          btnAttach.disabled = false;
          btnAttach.textContent = "Attach Page to Active Task";
          if (chrome.runtime.lastError) {
            alert("Failed to attach page.");
            return;
          }
          if (response && response.success) {
            alert("Page attachment queued and syncing!");
          } else {
            alert("Failed to attach page.");
          }
        }
      );
    });
    btnCapture.addEventListener("click", async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length === 0 || !tabs[0].url) {
        alert("No active page detected.");
        return;
      }
      const activeTab = tabs[0];
      btnCapture.disabled = true;
      btnCapture.textContent = "Sending...";
      chrome.runtime.sendMessage(
        {
          action: "ADD_EVENT",
          event: {
            type: "deadline",
            // Set as deadline type so Android Core creates a new proposed task
            data: {
              title: `Read: ${activeTab.title || "Webpage"}`,
              date: new Date(Date.now() + 864e5 * 2).toISOString(),
              // Proposed deadline in 2 days
              sourceUrl: activeTab.url,
              isCaptureProposal: true
            }
          }
        },
        (response) => {
          btnCapture.disabled = false;
          btnCapture.textContent = "Create Task from Page";
          if (chrome.runtime.lastError) {
            alert("Failed to send task proposal.");
            return;
          }
          if (response && response.success) {
            alert("Task proposal sent to AKRAMYG app!");
          } else {
            alert("Failed to send task proposal.");
          }
        }
      );
    });
    btnSummarize.addEventListener("click", async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length === 0 || !tabs[0].id) {
        alert("No active page detected.");
        return;
      }
      const activeTab = tabs[0];
      btnSummarize.disabled = true;
      btnSummarize.textContent = "Scraping content...";
      summaryArea.style.display = "none";
      try {
        chrome.tabs.sendMessage(activeTab.id, { action: "SCRAPE_PAGE" }, async (scrapedData) => {
          if (!scrapedData || !scrapedData.text) {
            btnSummarize.disabled = false;
            btnSummarize.textContent = "Summarize Current Page";
            alert("Could not read page text. Make sure you are on a webpage and refresh the page.");
            return;
          }
          btnSummarize.textContent = "Generating summary...";
          const configResult = await chrome.storage.local.get("config");
          const config = configResult.config || { androidIp: "192.168.1.100", androidPort: "8080" };
          try {
            const response = await fetch(`http://${config.androidIp}:${config.androidPort}/summarize`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              body: JSON.stringify({
                url: scrapedData.url,
                title: scrapedData.title,
                text: scrapedData.text
              })
            });
            if (!response.ok) {
              throw new Error(`Server returned code ${response.status}`);
            }
            const resultData = await response.json();
            btnSummarize.disabled = false;
            btnSummarize.textContent = "Summarize Current Page";
            summaryArea.style.display = "block";
            summaryArea.textContent = resultData.summary || "No summary returned by AKRAMYG Core.";
          } catch (fetchErr) {
            console.error(fetchErr);
            btnSummarize.disabled = false;
            btnSummarize.textContent = "Summarize Current Page";
            alert("Failed to connect to Android app for summarization. Check server status.");
          }
        });
      } catch (msgErr) {
        console.error(msgErr);
        btnSummarize.disabled = false;
        btnSummarize.textContent = "Summarize Current Page";
        alert("Unable to communicate with the page. Try refreshing the page.");
      }
    });
    async function triggerPageScan() {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length === 0 || !tabs[0].id) {
        showManualFallback();
        return;
      }
      const activeTab = tabs[0];
      if (activeTab.url && (activeTab.url.startsWith("chrome://") || activeTab.url.startsWith("edge://") || activeTab.url.startsWith("about:"))) {
        showManualFallback();
        return;
      }
      detectedList.innerHTML = '<div style="font-size:11px;color:var(--text-muted);">Scanning page...</div>';
      detectedItemsContainer.style.display = "block";
      try {
        chrome.tabs.sendMessage(activeTab.id, { action: "MANUAL_SCAN_PAGE" }, (response) => {
          if (chrome.runtime.lastError || !response || !response.deadlines) {
            showManualFallback();
            return;
          }
          localDetectedDeadlines = response.deadlines;
          if (localDetectedDeadlines.length === 0) {
            showManualFallback();
          } else {
            renderDetectedItems(localDetectedDeadlines);
          }
        });
      } catch (e) {
        showManualFallback();
      }
    }
    function showManualFallback() {
      detectedItemsContainer.style.display = "none";
      fallbackMessage.textContent = "No deadlines auto-detected. Add manually:";
      manualFallbackContainer.style.display = "block";
    }
    function renderDetectedItems(deadlines) {
      detectedList.innerHTML = "";
      detectedItemsContainer.style.display = "block";
      manualFallbackContainer.style.display = "none";
      deadlines.forEach((item, index) => {
        const div = document.createElement("div");
        div.className = "detected-item";
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = true;
        checkbox.id = `detect-item-${index}`;
        const details = document.createElement("div");
        details.className = "detected-item-details";
        const titleSpan = document.createElement("span");
        titleSpan.className = "detected-item-title";
        titleSpan.textContent = item.title.length > 50 ? item.title.substring(0, 50) + "..." : item.title;
        const dateSpan = document.createElement("span");
        dateSpan.className = "detected-item-date";
        dateSpan.textContent = `Due: ${item.date}`;
        details.appendChild(titleSpan);
        details.appendChild(dateSpan);
        div.appendChild(checkbox);
        div.appendChild(details);
        detectedList.appendChild(div);
      });
    }
    btnScan.addEventListener("click", (e) => {
      e.preventDefault();
      triggerPageScan();
    });
    btnSyncDetected.addEventListener("click", () => {
      let syncCount = 0;
      localDetectedDeadlines.forEach((item, index) => {
        const checkbox = document.getElementById(`detect-item-${index}`);
        if (checkbox && checkbox.checked) {
          syncCount++;
          chrome.runtime.sendMessage({
            action: "ADD_EVENT",
            event: {
              type: "deadline",
              data: item
            }
          });
        }
      });
      if (syncCount > 0) {
        alert(`Queued ${syncCount} deadlines for sync!`);
        triggerPageScan();
      } else {
        alert("No items selected.");
      }
    });
    btnAddManual.addEventListener("click", async () => {
      const title = manualTaskTitle.value.trim();
      const dateStr = manualTaskDate.value.trim();
      if (!title) {
        alert("Please enter a task title.");
        return;
      }
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const sourceUrl = tabs.length > 0 ? tabs[0].url || "" : "";
      btnAddManual.disabled = true;
      btnAddManual.textContent = "Adding...";
      const finalDate = dateStr ? new Date(dateStr).toISOString() : new Date(Date.now() + 864e5 * 2).toISOString();
      chrome.runtime.sendMessage(
        {
          action: "ADD_EVENT",
          event: {
            type: "deadline",
            data: {
              title,
              date: finalDate,
              sourceUrl,
              isCaptureProposal: true
            }
          }
        },
        (response) => {
          btnAddManual.disabled = false;
          btnAddManual.textContent = "Add Task";
          if (chrome.runtime.lastError) {
            alert("Failed to send task.");
            return;
          }
          if (response && response.success) {
            alert("Manual task added successfully!");
            manualTaskTitle.value = "";
            manualTaskDate.value = "";
          } else {
            alert("Failed to add manual task.");
          }
        }
      );
    });
    async function loadConfig() {
      const result = await chrome.storage.local.get("config");
      if (result.config) {
        inputIp.value = result.config.androidIp || "";
        inputPort.value = result.config.androidPort || "8080";
        inputCloudRelayEnabled.checked = result.config.cloudRelayEnabled || false;
        inputRelayUrl.value = result.config.cloudRelayUrl || "";
        inputRelayPairingKey.value = result.config.cloudRelayPairingKey || "";
      }
    }
    async function loadStatus() {
      chrome.runtime.sendMessage({ action: "GET_STATUS" }, (status) => {
        if (chrome.runtime.lastError) {
          statusDot.className = "status-dot status-disconnected";
          statusText.textContent = "Disconnected";
          return;
        }
        if (status) {
          if (status.isConnected) {
            statusDot.className = "status-dot status-connected";
            statusText.textContent = "Connected";
          } else {
            statusDot.className = "status-dot status-disconnected";
            statusText.textContent = "Disconnected";
          }
          if (status.activeTaskTitle) {
            activeTaskTitle.textContent = status.activeTaskTitle;
          } else {
            activeTaskTitle.textContent = "None";
          }
          if (status.isFocusSessionActive) {
            focusBadge.style.display = "inline-block";
          } else {
            focusBadge.style.display = "none";
          }
        }
      });
    }
    function switchToTab(tabName) {
      tabBtnCapture.classList.remove("active");
      tabBtnFocus.classList.remove("active");
      tabBtnSync.classList.remove("active");
      tabContentCapture.style.display = "none";
      tabContentFocus.style.display = "none";
      tabContentSync.style.display = "none";
      if (tabName === "capture") {
        tabBtnCapture.classList.add("active");
        tabContentCapture.style.display = "block";
      } else if (tabName === "focus") {
        tabBtnFocus.classList.add("active");
        tabContentFocus.style.display = "block";
        loadDistractionStats();
      } else {
        tabBtnSync.classList.add("active");
        tabContentSync.style.display = "block";
        loadSyncLogs();
      }
    }
    tabBtnCapture.addEventListener("click", () => switchToTab("capture"));
    tabBtnFocus.addEventListener("click", () => switchToTab("focus"));
    tabBtnSync.addEventListener("click", () => switchToTab("sync"));
    async function loadBlocklist() {
      chrome.runtime.sendMessage({ action: "GET_BLOCKLIST" }, (response) => {
        if (response && response.domains) {
          blocklistDomains.value = response.domains.join(", ");
        }
      });
    }
    btnSaveBlocklist.addEventListener("click", async () => {
      const domainList = blocklistDomains.value.split(",").map((d) => d.trim()).filter((d) => d.length > 0);
      chrome.runtime.sendMessage({ action: "SAVE_BLOCKLIST", domains: domainList }, (response) => {
        if (response && response.success) {
          alert("Blocklist saved successfully!");
        } else {
          alert("Failed to save blocklist.");
        }
      });
    });
    async function loadDistractionStats() {
      chrome.runtime.sendMessage({ action: "GET_DISTRACTION_STATS" }, (response) => {
        if (response) {
          distractionCountBadge.textContent = `${response.count} times`;
          if (response.logs && response.logs.length > 0) {
            distractionLogsFeed.innerHTML = response.logs.map((log) => `<div style="padding:2px 0;font-size:10px;">${log}</div>`).join("");
          } else {
            distractionLogsFeed.innerHTML = "No distractions blocked yet in this session.";
          }
        }
      });
    }
    async function loadSyncLogs() {
      const result = await chrome.storage.local.get("syncLogs");
      const logs = result.syncLogs || [];
      if (logs.length > 0) {
        syncConsoleLog.innerHTML = logs.map((log) => {
          const colorClass = log.isError ? "console-log-error" : "";
          return `<div class="console-log-line ${colorClass}">${log.timestamp} - ${log.message}</div>`;
        }).join("");
      } else {
        syncConsoleLog.textContent = "No sync operations logged yet.";
      }
    }
    btnSyncNow.addEventListener("click", async () => {
      btnSyncNow.disabled = true;
      btnSyncNow.textContent = "Syncing...";
      chrome.runtime.sendMessage({ action: "SYNC_NOW" }, async (response) => {
        btnSyncNow.disabled = false;
        btnSyncNow.textContent = "Force Sync Now";
        if (response && response.success) {
          alert("Sync successful!");
          loadStatus();
          loadSyncLogs();
        } else {
          alert(`Sync failed: ${response ? response.message : "Unknown error"}`);
          loadSyncLogs();
        }
      });
    });
    btnClearLogs.addEventListener("click", async () => {
      chrome.runtime.sendMessage({ action: "CLEAR_LOGS" }, (response) => {
        if (response && response.success) {
          loadSyncLogs();
          alert("Logs cleared!");
        }
      });
    });
    setInterval(() => {
      loadStatus();
      if (tabContentSync.style.display !== "none") {
        loadSyncLogs();
      }
      if (tabContentFocus.style.display !== "none") {
        loadDistractionStats();
      }
    }, 2e3);
  });
})();
//# sourceMappingURL=popup.js.map
