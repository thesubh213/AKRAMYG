"use strict";

// src/test_queue.ts
var storageMock = {};
var chromeMock = {
  storage: {
    local: {
      get: async (keys) => {
        const result = {};
        if (typeof keys === "string") {
          result[keys] = storageMock[keys];
        } else {
          keys.forEach((k) => {
            result[k] = storageMock[k];
          });
        }
        return result;
      },
      set: async (items) => {
        Object.keys(items).forEach((k) => {
          storageMock[k] = items[k];
        });
        return true;
      }
    }
  }
};
async function queueEventMock(event) {
  const fullEvent = {
    ...event,
    id: Math.random().toString(36).substring(2, 9),
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  const data = await chromeMock.storage.local.get("eventQueue");
  const queue = data.eventQueue || [];
  queue.push(fullEvent);
  await chromeMock.storage.local.set({ eventQueue: queue });
  return true;
}
async function syncEventsMock(mockFetchSucceeds) {
  const data = await chromeMock.storage.local.get("eventQueue");
  const queue = data.eventQueue || [];
  if (queue.length === 0) return true;
  try {
    if (!mockFetchSucceeds) {
      throw new Error("Network Unreachable");
    }
    await chromeMock.storage.local.set({ eventQueue: [] });
    return true;
  } catch (err) {
    return false;
  }
}
async function runTests() {
  console.log("--- Starting Chrome Extension Queue Tests ---");
  storageMock["eventQueue"] = [];
  await queueEventMock({ type: "deadline", data: { title: "Math Homework" } });
  await queueEventMock({ type: "distraction", data: { domain: "youtube.com" } });
  let data = await chromeMock.storage.local.get("eventQueue");
  let queue = data.eventQueue || [];
  if (queue.length === 2) {
    console.log("\u2705 PASS: Successfully queued 2 events.");
  } else {
    console.error("\u274C FAIL: Expected 2 events, got " + queue.length);
  }
  const syncOfflineResult = await syncEventsMock(false);
  data = await chromeMock.storage.local.get("eventQueue");
  queue = data.eventQueue || [];
  if (!syncOfflineResult && queue.length === 2) {
    console.log("\u2705 PASS: Offline sync correctly preserved queued events.");
  } else {
    console.error("\u274C FAIL: Offline sync cleared or modified queue incorrectly.");
  }
  const syncOnlineResult = await syncEventsMock(true);
  data = await chromeMock.storage.local.get("eventQueue");
  queue = data.eventQueue || [];
  if (syncOnlineResult && queue.length === 0) {
    console.log("\u2705 PASS: Online sync successfully cleared queue.");
  } else {
    console.error("\u274C FAIL: Online sync failed or did not clear queue.");
  }
  console.log("--- Chrome Extension Queue Tests Completed ---");
}
runTests().catch((err) => {
  console.error("Test execution failed:", err);
  process.exit(1);
});
