"use strict";
(() => {
  // src/crypto.ts
  async function deriveKey(passphrase) {
    const encoder = new TextEncoder();
    const keyMaterial = encoder.encode(passphrase);
    const hash = await crypto.subtle.digest("SHA-256", keyMaterial);
    return crypto.subtle.importKey(
      "raw",
      hash,
      { name: "AES-GCM" },
      false,
      ["encrypt", "decrypt"]
    );
  }
  async function deriveChannelId(passphrase) {
    const encoder = new TextEncoder();
    const keyMaterial = encoder.encode(passphrase);
    const hashBuffer = await crypto.subtle.digest("SHA-256", keyMaterial);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
    return hashHex.substring(0, 32);
  }
  async function encryptPayload(payload, passphrase) {
    const key = await deriveKey(passphrase);
    const encoder = new TextEncoder();
    const data = encoder.encode(payload);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ciphertextBuffer = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      data
    );
    const ciphertext = new Uint8Array(ciphertextBuffer);
    const combined = new Uint8Array(iv.length + ciphertext.length);
    combined.set(iv, 0);
    combined.set(ciphertext, iv.length);
    return arrayBufferToBase64(combined);
  }
  function arrayBufferToBase64(buffer) {
    let binary = "";
    const len = buffer.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(buffer[i]);
    }
    return btoa(binary);
  }

  // src/background.ts
  async function isBypassed(tabId, domain) {
    const result = await chrome.storage.local.get("bypassedTabs");
    const bypassed = result.bypassedTabs || {};
    return bypassed[tabId] === domain;
  }
  async function addBypass(tabId, domain) {
    const result = await chrome.storage.local.get("bypassedTabs");
    const bypassed = result.bypassedTabs || {};
    bypassed[tabId] = domain;
    await chrome.storage.local.set({ bypassedTabs: bypassed });
  }
  async function clearBypasses() {
    await chrome.storage.local.set({ bypassedTabs: {} });
  }
  async function discoverAndroidIp() {
    const subnets = ["192.168.1", "192.168.0", "192.168.2", "192.168.100", "10.0.0", "172.16.0"];
    const config = await getConfig();
    if (config.androidIp) {
      const parts = config.androidIp.split(".");
      if (parts.length === 4) {
        const activeSubnet = `${parts[0]}.${parts[1]}.${parts[2]}`;
        if (!subnets.includes(activeSubnet)) {
          subnets.unshift(activeSubnet);
        }
      }
    }
    console.log("Initiating automatic IP discovery scan on subnets:", subnets);
    for (const subnet of subnets) {
      const promises = [];
      const controllers = [];
      for (let i = 1; i <= 254; i++) {
        const ip = `${subnet}.${i}`;
        const controller = new AbortController();
        controllers.push(controller);
        const timeoutId = setTimeout(() => controller.abort(), 1200);
        const fetchPromise = fetch(`http://${ip}:8080/status`, {
          signal: controller.signal,
          method: "GET",
          headers: { "Accept": "application/json" }
        }).then(async (res) => {
          clearTimeout(timeoutId);
          if (res.ok) {
            const status = await res.json();
            if (status.isConnected) {
              return ip;
            }
          }
          throw new Error("Not the sync server");
        }).catch(() => {
          clearTimeout(timeoutId);
          return "";
        });
        promises.push(fetchPromise);
      }
      try {
        const results = await Promise.all(promises);
        const foundIp = results.find((ip) => ip !== "");
        if (foundIp) {
          controllers.forEach((c) => c.abort());
          console.log("Found Android Core Sync Server at:", foundIp);
          return foundIp;
        }
      } catch (e) {
        controllers.forEach((c) => c.abort());
      }
    }
    return null;
  }
  async function completeSubtask(subtaskId) {
    const config = await getConfig();
    const url = `http://${config.androidIp}:${config.androidPort}/complete-subtask`;
    console.log(`Completing subtask ${subtaskId} via Android Core at ${url}...`);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({ subtaskId })
      });
      if (response.ok) {
        await syncEventsWithAndroid();
        return { success: true, message: "Subtask completed successfully." };
      } else {
        throw new Error(`Server returned code ${response.status}`);
      }
    } catch (err) {
      console.error("Failed to complete subtask:", err);
      return { success: false, message: err.message };
    }
  }
  async function completeTask(taskId) {
    const config = await getConfig();
    const url = `http://${config.androidIp}:${config.androidPort}/complete-task`;
    console.log(`Completing task ${taskId} via Android Core at ${url}...`);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({ taskId })
      });
      if (response.ok) {
        await syncEventsWithAndroid();
        return { success: true, message: "Task completed successfully." };
      } else {
        throw new Error(`Server returned code ${response.status}`);
      }
    } catch (err) {
      console.error("Failed to complete task:", err);
      return { success: false, message: err.message };
    }
  }
  var DEFAULT_CONFIG = {
    androidIp: "192.168.1.100",
    // Mock placeholder, user configures in popup
    androidPort: "8080",
    syncIntervalMins: 1,
    cloudRelayEnabled: false,
    cloudRelayUrl: "http://192.168.1.100:8080/relay",
    cloudRelayPairingKey: "",
    distractionDomains: ["youtube.com", "facebook.com", "reddit.com", "instagram.com", "twitter.com", "x.com", "netflix.com"]
  };
  chrome.alarms.create("sync_alarm", { periodInMinutes: DEFAULT_CONFIG.syncIntervalMins });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "sync_alarm") {
      syncEventsWithAndroid();
    }
  });
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    checkTabContext(activeInfo.tabId);
  });
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete") {
      checkTabContext(tabId);
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "ADD_EVENT") {
      queueEvent(message.event).then((success) => {
        sendResponse({ success });
        if (success) {
          syncEventsWithAndroid();
        }
      });
      return true;
    }
    if (message.action === "UPDATE_CONFIG") {
      saveConfig(message.config).then((success) => {
        sendResponse({ success });
        chrome.alarms.clear("sync_alarm").then(() => {
          chrome.alarms.create("sync_alarm", { periodInMinutes: message.config.syncIntervalMins || 1 });
        });
        syncEventsWithAndroid();
      });
      return true;
    }
    if (message.action === "GET_STATUS") {
      getStatus().then(sendResponse);
      return true;
    }
    if (message.action === "SYNC_NOW") {
      syncEventsWithAndroid().then((result) => {
        sendResponse(result);
      });
      return true;
    }
    if (message.action === "CLEAR_LOGS") {
      chrome.storage.local.set({ syncLogs: [] }).then(() => {
        sendResponse({ success: true });
      });
      return true;
    }
    if (message.action === "SAVE_BLOCKLIST") {
      getConfig().then((config) => {
        const newConfig = { ...config, distractionDomains: message.domains };
        saveConfig(newConfig).then(() => {
          sendResponse({ success: true });
        });
      });
      return true;
    }
    if (message.action === "GET_BLOCKLIST") {
      getConfig().then((config) => {
        sendResponse({ success: true, domains: config.distractionDomains || DEFAULT_CONFIG.distractionDomains });
      });
      return true;
    }
    if (message.action === "GET_DISTRACTION_STATS") {
      Promise.all([
        chrome.storage.local.get("distractionCount"),
        chrome.storage.local.get("distractionLogs")
      ]).then(([countResult, logsResult]) => {
        sendResponse({
          count: countResult.distractionCount || 0,
          logs: logsResult.distractionLogs || []
        });
      });
      return true;
    }
    if (message.action === "BYPASS_DISTRACTION") {
      const { url, domain } = message;
      const tabId = message.tabId || sender.tab?.id;
      if (tabId) {
        addBypass(tabId, domain).then(() => {
          chrome.tabs.update(tabId, { url }).then(() => {
            sendResponse({ success: true });
          });
        });
      } else {
        sendResponse({ success: false });
      }
      return true;
    }
    if (message.action === "COMPLETE_SUBTASK") {
      const { subtaskId } = message;
      completeSubtask(subtaskId).then((result) => {
        sendResponse(result);
      });
      return true;
    }
    if (message.action === "COMPLETE_TASK") {
      const { taskId } = message;
      completeTask(taskId).then((result) => {
        sendResponse(result);
      });
      return true;
    }
    if (message.action === "CLOSE_CURRENT_TAB") {
      const tabId = sender.tab?.id;
      if (tabId) {
        chrome.tabs.remove(tabId);
      }
      return true;
    }
    if (message.action === "DISCOVER_IP") {
      discoverAndroidIp().then((ip) => {
        sendResponse({ success: !!ip, ip });
      });
      return true;
    }
  });
  async function getConfig() {
    const result = await chrome.storage.local.get("config");
    return result.config || DEFAULT_CONFIG;
  }
  async function saveConfig(config) {
    await chrome.storage.local.set({ config });
    return true;
  }
  async function getStatus() {
    const result = await chrome.storage.local.get(["isConnected", "activeTaskId", "activeTaskTitle", "activeTaskDescription", "pendingSubtasks", "isFocusSessionActive", "lastSyncTime"]);
    return {
      isConnected: result.isConnected || false,
      activeTaskId: result.activeTaskId || null,
      activeTaskTitle: result.activeTaskTitle || null,
      activeTaskDescription: result.activeTaskDescription || null,
      pendingSubtasks: result.pendingSubtasks || null,
      isFocusSessionActive: result.isFocusSessionActive || false,
      lastSyncTime: result.lastSyncTime || null
    };
  }
  async function queueEvent(event) {
    const fullEvent = {
      ...event,
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    const data = await chrome.storage.local.get("eventQueue");
    const queue = data.eventQueue || [];
    const MAX_QUEUE_SIZE = 1e3;
    while (queue.length >= MAX_QUEUE_SIZE) {
      queue.shift();
    }
    queue.push(fullEvent);
    await chrome.storage.local.set({ eventQueue: queue });
    console.log("Queued event:", fullEvent);
    return true;
  }
  async function checkTabContext(tabId) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (!tab.url) return;
      if (tab.url.startsWith("chrome://") || tab.url.startsWith("edge://") || tab.url.startsWith("about:") || tab.url.startsWith("chrome-extension://")) {
        return;
      }
      const url = new URL(tab.url);
      const domain = url.hostname;
      const status = await getStatus();
      const config = await getConfig();
      const distractionDomains = config.distractionDomains || DEFAULT_CONFIG.distractionDomains || [];
      if (status.isFocusSessionActive) {
        const isDistracted = distractionDomains.some((d) => domain.includes(d));
        if (isDistracted) {
          const bypassed = await isBypassed(tabId, domain);
          if (!bypassed) {
            console.log("Distraction detected:", domain, "Redirecting to interstitial.");
            const stats = await chrome.storage.local.get("distractionCount");
            const count = (stats.distractionCount || 0) + 1;
            await chrome.storage.local.set({ distractionCount: count });
            const logData = await chrome.storage.local.get("distractionLogs");
            const logs = logData.distractionLogs || [];
            logs.push(`${(/* @__PURE__ */ new Date()).toLocaleTimeString()} - Blocked ${domain}`);
            if (logs.length > 5) logs.shift();
            await chrome.storage.local.set({ distractionLogs: logs });
            await queueEvent({
              type: "distraction",
              data: {
                domain,
                url: tab.url,
                title: tab.title || "",
                activeTask: status.activeTaskId
              }
            });
            const interstitialUrl = chrome.runtime.getURL("interstitial.html") + `?originalUrl=${encodeURIComponent(tab.url)}&domain=${encodeURIComponent(domain)}`;
            chrome.tabs.update(tabId, { url: interstitialUrl });
            return;
          }
        }
      }
      await queueEvent({
        type: "entity",
        data: {
          category: "active_tab",
          value: tab.url,
          title: tab.title || ""
        }
      });
    } catch (err) {
      console.error("Error checking tab context:", err);
    }
  }
  async function syncViaCloudRelay(config, queue) {
    if (!config.cloudRelayPairingKey) {
      throw new Error("Cloud relay pairing key is not configured.");
    }
    const channelId = await deriveChannelId(config.cloudRelayPairingKey);
    const relayUrl = `${config.cloudRelayUrl}/${channelId}`;
    console.log(`Syncing via Zero-Knowledge Cloud Relay at ${relayUrl}...`);
    if (queue.length === 0) {
      await logSyncResult("Cloud relay validated. Queue empty.");
      return { success: true, message: "Connected to relay. Event queue empty." };
    }
    const payloadStr = JSON.stringify({ events: queue });
    const encryptedBase64 = await encryptPayload(payloadStr, config.cloudRelayPairingKey);
    const response = await fetch(relayUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({ payload: encryptedBase64 })
    });
    if (!response.ok) {
      throw new Error(`Relay server returned code ${response.status}`);
    }
    await chrome.storage.local.set({
      isConnected: true,
      lastSyncTime: (/* @__PURE__ */ new Date()).toISOString(),
      eventQueue: []
    });
    console.log(`Successfully synced ${queue.length} events via Cloud Relay.`);
    return { success: true, message: `Synced ${queue.length} events via Cloud Relay.` };
  }
  async function syncEventsWithAndroid() {
    const config = await getConfig();
    const data = await chrome.storage.local.get("eventQueue");
    const queue = data.eventQueue || [];
    if (config.cloudRelayEnabled) {
      try {
        return await syncViaCloudRelay(config, queue);
      } catch (relayErr) {
        console.warn("Forced Cloud Relay failed:", relayErr);
        await chrome.storage.local.set({ isConnected: false });
        return { success: false, message: `Cloud relay error: ${relayErr.message}` };
      }
    }
    const url = `http://${config.androidIp}:${config.androidPort}/sync`;
    const statusUrl = `http://${config.androidIp}:${config.androidPort}/status`;
    console.log(`Syncing with Android Core at ${url}...`);
    try {
      const statusResponse = await fetch(statusUrl, {
        method: "GET",
        headers: { "Accept": "application/json" }
      });
      if (!statusResponse.ok) {
        throw new Error(`Server returned status ${statusResponse.status}`);
      }
      const appState = await statusResponse.json();
      const currentStatus = await getStatus();
      if (currentStatus.isFocusSessionActive && !appState.isFocusSessionActive) {
        console.log("Focus session ended. Clearing bypass cache.");
        await clearBypasses();
      }
      await chrome.storage.local.set({
        isConnected: true,
        activeTaskId: appState.activeTaskId || null,
        activeTaskTitle: appState.activeTaskTitle || null,
        activeTaskDescription: appState.activeTaskDescription || null,
        pendingSubtasks: appState.pendingSubtasks || null,
        isFocusSessionActive: appState.isFocusSessionActive || false,
        lastSyncTime: (/* @__PURE__ */ new Date()).toISOString()
      });
      if (queue.length > 0) {
        const syncResponse = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: JSON.stringify({ events: queue })
        });
        if (syncResponse.ok) {
          await chrome.storage.local.set({ eventQueue: [] });
          console.log(`Successfully synced ${queue.length} events.`);
          await logSyncResult(`Synced ${queue.length} events locally.`);
          return { success: true, message: `Synced ${queue.length} events.` };
        } else {
          throw new Error(`Sync post failed with code ${syncResponse.status}`);
        }
      }
      await logSyncResult("Connection validated. Queue empty.");
      return { success: true, message: "Connected. Queue empty." };
    } catch (err) {
      console.warn("Local sync failed. Checking Cloud Relay fallback... Error:", err);
      await logSyncResult(`Local connection failed. Trying Cloud Relay...`, true);
      if (config.cloudRelayPairingKey) {
        try {
          const relayResult = await syncViaCloudRelay(config, queue);
          await logSyncResult(`Relay Sync Success: ${relayResult.message}`);
          return relayResult;
        } catch (relayErr) {
          console.error("Cloud Relay fallback also failed:", relayErr);
          await logSyncResult(`Relay Sync Fail: ${relayErr.message}`, true);
        }
      }
      await chrome.storage.local.set({ isConnected: false });
      return { success: false, message: `Connection failed: ${err.message}` };
    }
  }
  async function logSyncResult(message, isError = false) {
    const data = await chrome.storage.local.get("syncLogs");
    const logs = data.syncLogs || [];
    logs.push({
      timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
      message,
      isError
    });
    if (logs.length > 6) {
      logs.shift();
    }
    await chrome.storage.local.set({ syncLogs: logs });
  }
  async function pollSyncStatus() {
    try {
      const config = await getConfig();
      if (!config.cloudRelayEnabled && config.androidIp) {
        const statusUrl = `http://${config.androidIp}:${config.androidPort}/status`;
        const response = await fetch(statusUrl, {
          method: "GET",
          headers: { "Accept": "application/json" }
        });
        if (response.ok) {
          const appState = await response.json();
          const currentStatus = await getStatus();
          if (currentStatus.isFocusSessionActive && !appState.isFocusSessionActive) {
            console.log("Focus session ended. Clearing bypass cache.");
            await clearBypasses();
          }
          await chrome.storage.local.set({
            isConnected: true,
            activeTaskId: appState.activeTaskId || null,
            activeTaskTitle: appState.activeTaskTitle || null,
            activeTaskDescription: appState.activeTaskDescription || null,
            pendingSubtasks: appState.pendingSubtasks || null,
            isFocusSessionActive: appState.isFocusSessionActive || false,
            lastSyncTime: (/* @__PURE__ */ new Date()).toISOString()
          });
        } else {
          await chrome.storage.local.set({ isConnected: false });
        }
      }
    } catch (e) {
    }
  }
  setInterval(pollSyncStatus, 3e3);
})();
//# sourceMappingURL=background.js.map
